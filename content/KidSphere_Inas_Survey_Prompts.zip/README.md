# KidSphere / Inas Kindergarten Survey Prompts

This ZIP contains two ready-to-use prompts:

- `CLAUDE_PROMPT.md` — for Claude to design and build the complete application.
- `CURSOR_PROMPT.md` — for Cursor to implement the application directly in a code repository.
- `SURVEY_SOURCE_AR.md` — locked Arabic source questionnaire from Inas.

Important: the questionnaire is content-locked and must remain exactly 27 questions with the original wording and choices.
