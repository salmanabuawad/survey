You are responsible for designing and implementing the complete application.

CRITICAL CONTENT LOCK:
The questionnaire content below was written and approved by Inas and is the authoritative source of truth.
Do not rewrite, correct, shorten, expand, reorder, merge, split, add, or remove any question, section, answer option, introduction text, or thank-you text.
There must be exactly 27 numbered questions. UI/UX may be improved, but research content must remain unchanged.

Build an Arabic-first, true RTL, mobile-first survey app that is highly attractive, modern, warm, professional, and suitable for adult kindergarten teachers. It must not look like Google Forms or a government form.

Preferred stack:
- Next.js
- TypeScript
- React
- Tailwind CSS
- shadcn/ui
- PostgreSQL
- Prisma
- Zod
- Recharts

Requirements:
- <html lang="ar" dir="rtl">
- structural RTL everywhere
- premium Arabic typography (IBM Plex Sans Arabic or Noto Sans Arabic)
- multi-step wizard by original sections
- progress bar and step indicator
- previous/next navigation
- autosave unfinished answers locally
- restore on refresh
- final submit persists to PostgreSQL
- UUID response IDs
- transaction on submission
- prevent accidental double-submit
- survey version: inas-kindergarten-teachers-ar-v1
- database stores exact question text shown at submission time
- anonymous: do not request/persist name, phone, email, ID number, child names, or IP address
- optional helper near free-text fields: "يرجى عدم ذكر أسماء الأطفال أو معلومات تكشف هويتهم."
- secure admin dashboard
- total submissions
- submissions by day
- average completion time
- distributions and percentages
- horizontal RTL-friendly charts for long Arabic labels
- filters by framework type, age group, group size, experience
- open-text response viewer
- CSV export, one row per response, one column per question
- mobile tested at 360px and 390px
- no horizontal scroll
- accessible labels, contrast, keyboard navigation, focus states, ARIA
- `.env.example`
- Prisma schema and migrations
- README with local setup and Vercel + Supabase/Neon/PostgreSQL deployment instructions

Visual direction:
- warm teal/turquoise
- soft violet
- peach/coral accent
- cream/off-white background
- soft rounded cards
- subtle gradients
- elegant educational/emotional abstract motifs
- large tap targets
- smooth but fast transitions
- sophisticated, not childish

Input behavior:
- Use single choice where the source presents one scale/choice.
- Use multiple selection where the source explicitly says multiple answers or clearly uses a checklist.
- Where "أخرى: __________" exists, reveal a text input when "أخرى" is selected while preserving the visible label exactly.
- Questions 6, 25, 26, and 27 are free-text.

MANDATORY FINAL QA:
Before declaring completion, compare implementation line-by-line against the locked source and verify:
- exactly 27 numbered questions
- Q1-Q27 all exist
- no Q28+
- exact Arabic question text
- exact answer labels
- correct section order and names
- exact introduction
- exact thank-you text
- no extra research questions
Fix all differences before finishing.

DELIVERY EXPECTATION:
Build the app, not just a mockup. Produce the full codebase with database persistence and admin analytics. Make strong UX/design decisions without changing the research content.

LOCKED SURVEY SOURCE:

# استبيان للمعلمات في رياض الأطفال

## تحديد احتياجات الأطفال وبناء حلول تربوية واجتماعية وعاطفية مناسبة

**المعلمة الفاضلة،**

نحن نعمل على تطوير برنامج/منصة رقمية تهدف إلى دعم الأطفال في مرحلة الطفولة المبكرة، من خلال اللعب الهادف، التعلم، وتنمية المهارات الاجتماعية والعاطفية، مع تعزيز التعاون بين الطفل، الأهل والإطار التربوي.

يهدف هذا الاستبيان إلى التعرف على احتياجات الأطفال من وجهة نظر الطاقم التربوي، وفهم التحديات الموجودة في الروضة، بهدف تطوير محتوى وأدوات عملية وملائمة للاحتياجات الحقيقية في الميدان.

**الاستبيان مجهول الهوية، وتستخدم المعلومات لأغراض التطوير والتخطيط فقط.**

---

## أولاً: معلومات عن الإطار التربوي

**1. نوع الإطار التربوي:**

- حضانة
- روضة أطفال
- بستان
- إطار آخر: __________

**2. الفئة العمرية للأطفال:**

- 3–4 سنوات
- 4–5 سنوات
- 5–6 سنوات
- أكثر من ذلك

**3. عدد الأطفال في المجموعة:**

- أقل من 15
- 15–20
- 21–25
- أكثر من 25

**4. منذ كم سنة تعملين في مجال التربية والتعليم في الطفولة المبكرة؟**

- أقل من 3 سنوات
- 3–5 سنوات
- 6–10 سنوات
- أكثر من 10 سنوات

---

# ثانياً: ملاحظة احتياجات الأطفال

**5. ما المجالات التي تلاحظين أن الأطفال بحاجة إلى دعم أكبر فيها؟**
يمكن اختيار أكثر من إجابة:

- التعبير عن المشاعر
- التعرف على المشاعر وتسميتها
- تنظيم المشاعر والانفعالات
- التعامل مع الغضب
- التعامل مع الخوف والقلق
- تحمل الإحباط
- الثقة بالنفس
- الاستقلالية
- التواصل مع الآخرين
- تكوين علاقات اجتماعية
- المشاركة والتعاون
- حل النزاعات
- التعاطف
- التركيز والانتباه
- اللغة والتعبير
- المهارات الحركية
- حل المشكلات والتفكير
- أخرى: __________

**6. ما أبرز الصعوبات السلوكية أو العاطفية التي تواجهينها في المجموعة؟**

Free-text answer.

**7. هل تلاحظين وجود أطفال يواجهون صعوبة في التعبير عن مشاعرهم أو احتياجاتهم؟**

- بشكل كبير
- بدرجة متوسطة
- بدرجة قليلة
- لا ألاحظ ذلك

---

# ثالثاً: المهارات الاجتماعية والعاطفية – SEL

**8. إلى أي درجة ترين أن الأطفال بحاجة إلى تطوير المهارات الاجتماعية والعاطفية (SEL)؟**

- حاجة كبيرة جداً
- حاجة كبيرة
- حاجة متوسطة
- حاجة قليلة

**9. ما المهارات التي ترين أنها الأكثر أهمية للأطفال في هذه المرحلة؟**

- التعرف على المشاعر
- التعبير عن المشاعر
- ضبط الانفعالات
- التعاطف
- التعاون
- المشاركة
- احترام الآخر
- حل المشكلات
- حل النزاعات
- الصبر وتأجيل الإشباع
- المرونة والقدرة على التكيف
- الثقة بالنفس
- الشعور بالأمان والانتماء
- أخرى: __________

**10. ما المواقف التي تثير عادةً صعوبة عاطفية أو اجتماعية لدى الأطفال؟**

- الانتقال من نشاط إلى آخر
- مشاركة الألعاب
- الانتظار
- الخلاف مع طفل آخر
- الخسارة أو الفشل
- تغيير الروتين
- الانفصال عن الوالدين
- النشاط الجماعي
- وضع الحدود
- أخرى: __________

---

# رابعاً: اللعب والتعلم

**11. إلى أي درجة تستخدمين اللعب كوسيلة للتعلم والتطور؟**

- دائماً
- غالباً
- أحياناً
- نادراً

**12. ما أنواع الأنشطة التي تجدينها أكثر فاعلية مع الأطفال؟**

- الألعاب الجماعية
- الألعاب الفردية
- القصص
- الرسم والفنون
- الموسيقى والغناء
- الحركة والرياضة
- ألعاب حل المشكلات
- لعب الأدوار
- أنشطة التعرف على المشاعر
- أنشطة الاسترخاء والتنفس
- أنشطة حسية
- أخرى: __________

**13. ما المدة المثالية للنشاط الواحد بالنسبة للأطفال في مجموعتك؟**

- 5 دقائق
- 10 دقائق
- 15 دقيقة
- 20 دقيقة
- أكثر من 20 دقيقة

---

# خامساً: احتياجات المعلمة

**14. ما الأدوات التي تحتاجين إليها أكثر لمساعدتك في التعامل مع الأطفال؟**

- أنشطة جاهزة وسهلة التطبيق
- ألعاب لتنمية المهارات الاجتماعية
- أدوات للتعامل مع المشاعر
- قصص تربوية
- أدوات لتخفيف التوتر والقلق
- أدوات للتعامل مع السلوكيات الصعبة
- أنشطة لتعزيز الثقة بالنفس
- أدوات لمساعدة الأطفال على حل النزاعات
- مواد لإشراك الأهل
- إرشادات مهنية للمعلمة
- أخرى: __________

**15. ما أكثر ما يصعّب عليك تقديم الدعم العاطفي والاجتماعي للأطفال؟**

- ضيق الوقت
- عدد الأطفال الكبير
- نقص الأدوات والمواد
- اختلاف احتياجات الأطفال
- نقص التدريب المهني
- صعوبة إشراك الأهل
- السلوكيات الصعبة
- ضغط العمل
- أخرى: __________

---

# سادساً: التعاون مع الأهل

**16. إلى أي درجة ترين أن التعاون بين الروضة والأهل يؤثر على تطور الطفل؟**

- بدرجة كبيرة جداً
- بدرجة كبيرة
- بدرجة متوسطة
- بدرجة قليلة

**17. في أي مجالات تحتاجين إلى تعاون أكبر مع الأهل؟**

- فهم احتياجات الطفل
- التعامل مع السلوك
- دعم المشاعر
- تعزيز الاستقلالية
- استخدام الشاشات
- تنظيم الروتين اليومي
- تعزيز التواصل بين الأهل والطفل
- تعزيز المهارات الاجتماعية
- أخرى: __________

**18. هل ترين أن وجود أنشطة يمكن تنفيذها في الروضة ثم استكمالها في المنزل سيكون مفيداً؟**

- مفيد جداً
- مفيد
- ربما
- غير ضروري

---

# سابعاً: فكرة البرنامج/التطبيق

**19. لو توفر تطبيق يقدم أنشطة قصيرة ومهنية ومناسبة لعمر الأطفال، هل ترين أنه سيكون مفيداً في الروضة؟**

- مفيد جداً
- مفيد
- ربما
- غير مفيد

**20. ما الخصائص التي ترين أنها ضرورية في التطبيق؟**

- محتوى مناسب للعمر
- أنشطة قصيرة وسهلة التطبيق
- محتوى باللغة العربية
- أنشطة فردية وجماعية
- أنشطة لتنمية المهارات الاجتماعية والعاطفية
- قصص تفاعلية
- ألعاب تعليمية
- أدوات تساعد المعلمة على متابعة تطور الطفل
- اقتراح أنشطة حسب احتياجات المجموعة
- إمكانية مشاركة الأنشطة مع الأهل
- إرشادات للمعلمة
- محتوى مبني على أسس تربوية ومهنية
- تقليل الاعتماد على الشاشة واستخدامها كوسيلة وليس كغاية
- أخرى: __________

---

# ثامناً: التخصيص حسب احتياجات الروضة

**21. هل ترين أهمية أن يتم تحديد احتياجات كل مجموعة أطفال قبل اختيار الأنشطة المناسبة؟**

- مهمة جداً
- مهمة
- متوسطة
- غير مهمة

**22. ما المجالات التي تفضلين أن يتم تقييمها في بداية العام أو قبل استخدام البرنامج؟**

- المهارات الاجتماعية
- المهارات العاطفية
- التواصل
- الاستقلالية
- الثقة بالنفس
- القدرة على التركيز
- التعامل مع الإحباط
- التعاون والمشاركة
- الشعور بالأمان والانتماء
- أخرى: __________

---

# تاسعاً: قياس التطور والأثر

**23. كيف تتابعين عادةً التطور العاطفي والاجتماعي للأطفال؟**

- ملاحظات يومية
- محادثات مع الطفل
- لقاءات مع الأهل
- أدوات تقييم منظمة
- لا توجد أداة ثابتة
- أخرى: __________

**24. هل ترين أن من المهم أن يوفر البرنامج أداة تساعد المعلمة على متابعة تطور الطفل؟**

- مهم جداً
- مهم
- ربما
- غير مهم

---

# عاشراً: سؤال مفتوح

**25. ما الاحتياج الأساسي الذي تتمنين أن يساعدك البرنامج في تلبيته داخل الروضة؟**

Free-text answer.

**26. إذا كان بإمكانك إضافة ميزة واحدة فقط إلى التطبيق، فما هي؟**

Free-text answer.

**27. ما النصيحة التي تقدمينها لنا قبل تطوير البرنامج؟**

Free-text answer.

---

## شكراً لمشاركتك

رأيك المهني مهم جداً بالنسبة لنا.
الهدف هو تطوير حل يستجيب للاحتياجات الحقيقية للأطفال والمعلمات والأهل، ويجعل من **اللعب وسيلة للتعلم، والتواصل، والنمو الاجتماعي والعاطفي، وتعزيز المرونة والحصانة النفسية لدى الطفل.**
